
$(document).ready(function(){
  setTimeout(function(){

    window.dispatchEvent(new Event("AR_BEGIN"));

    $("#drawing").addClass("animate");


    setTimeout(function(){
      window.dispatchEvent(new Event("AR_END"));
    }, 13.8 * 1000);

  }, 1000);
});